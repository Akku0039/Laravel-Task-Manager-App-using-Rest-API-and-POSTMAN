<header class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0 shadow">
    <a href="#" class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-6">
        Task Manager
    </a>
<button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#sidebarmenu">
    <span class="navbar-toggler-icon"></span>
</button>
<div class="navbar-nav">
    <div class="nav-item text-nowrap">
        <a class="#">All Tasks</a>
    </div>
</div>
</header>